function popup() {
    window.alert("O hai, I'm a javascript popup!");
}